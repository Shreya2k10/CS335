#include "astnode.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symbolTable.h"
#include "ThreeAC.cpp"
#include "ThreeAC.h"


// A function to check if a variable is declared in the current scope or any of its parent scopes
int is_declared(char* sym, int scope) {
    symbol* sym_entry = lookup(sym);
    while (sym_entry != NULL) {
        if (sym_entry->offset <= scope) {
            return 1;
        }
        sym_entry = sym_entry->next;
    }
    return 0;
}

// A function to check if two types are compatible for arithmetic operations
int is_compatible(int type1, int type2) {
    if (type1 == type2) {
        return 1;
    }
    if ((sizeof(type1) == sizeof(int)) || (sizeof(type1) == sizeof(float)) && (sizeof(type2) == sizeof(int)) || (sizeof(type2) == sizeof(float))) {
        return 1;
    }
    return 0;
}

// A function to check if the actual and formal arguments of a function match
int is_matching(ASTNode* actual, ASTNode* formal) {
    while (actual != NULL && formal != NULL) {
        if (!is_compatible(actual->globalindex, formal->globalindex)) {
            return 0;
        }
        actual = actual->right;
        formal = formal->right;
    }
    if (actual != NULL || formal != NULL) {
        return 0;
    }
    return 1;
}

void semantic_analysis(ASTNode* root, int scope) {
    if (root == NULL) {
        return;
    }
    if (strcmp(root->type, "VAR_DECL") == 0) {
        // Check if the variable is already declared in the same scope
        if (lookup(root->sym) != NULL) {
            printf("Semantic error: Variable %s is redeclared in scope \n", root->sym);
            exit(1);
        }
        // Insert the variable into the symbol table
        // Replace insert with insert_symbol
        insert_symbol(&(find_local_table(current_func)->vars), create_symbol(root->sym, root->globalindex, 0, 0, 0, ""));
    }
    else if (strcmp(root->type, "FUNC_DECL") == 0) {
        // Check if the function is already declared
        if (lookup(root->sym) != NULL) {
            printf("Semantic error: Function %s is redeclared\n", root->sym);
            exit(1);
        }
        // Insert the function into the symbol table
        // Replace insert with insert_symbol
        insert_symbol(&(find_local_table(current_func)->vars), create_symbol(root->sym, root->globalindex, 0, 0, 0, ""));
        // Perform semantic analysis on the function parameters and body in a new scope
        semantic_analysis(root->left, scope + 1); // Assuming left represents parameters
        semantic_analysis(root->right, scope + 1); // Assuming right represents function body
    }
    else if (strcmp(root->type, "VAR_USE") == 0) {
        // Check if the variable is declared
        if (!is_declared(root->sym, scope)) {
            printf("Semantic error: Variable %s is used without declaration in scope %d\n", root->sym, scope);
            exit(1);
        }
        // Set the type of the variable use ASTNode to the type of the variable declaration
        symbol* sym = lookup(root->sym);
        root->globalindex = sym->offset;
    }
    else {
        // Perform semantic analysis on the children of the ASTNode
        semantic_analysis(root->left, scope);
        semantic_analysis(root->right, scope);
    }
}
