// A header file for symbol table
#ifndef SYMBOL_TABLE_H
#define SYMBOL_TABLE_H
#include "symbol.h"

#include <stdlib.h>

#include <stdio.h>

#include <string.h>

static char* current_func = NULL;

// A structure to store a local symbol table for a function
typedef struct local_table {
  char *func_name; // The name of the function
  symbol *params; // A linked list of parameters
  symbol *vars; // A linked list of local variables
  int current_offset; // current size of the table
  struct local_table *next; // A pointer to the next local table
} local_table;

// A global symbol table that maps function names to their local tables
static local_table *global_table = NULL, *lt = NULL;


symbol *search_symbol(char *name, local_table *lt);



// A structure to store a local symbol table for a function
typedef struct local_table local_table;

// A global symbol table that maps function names to their local tables
extern local_table *global_table;

// A function to create a new symbol with the given information
symbol *create_symbol(char *name, char* type, int size, int offset, int line,
                      char *file);

// A function to create a new local table with the given function name
local_table *create_local_table(char *func_name);

// A function to insert a symbol into a linked list of symbols
void insert_symbol(symbol **head, symbol *s);

// A function to insert a local table into the global table
void insert_local_table(local_table *lt);

// A function to find a local table by the function name
local_table *find_local_table(char *func_name);

// A function to print a symbol
void print_symbol(symbol *s);

// A function to print a local table
void print_local_table(local_table *lt);

// A function to print the global table
void print_global_table();

// A variable to store the current offset within the function
extern int current_offset;

// A variable to store the current line number
extern int lineno;

// A variable to store the current file name
extern char *filename;


void dump_all_symbol_tables_to_csv();

void dump_symbol_table_to_csv(local_table *lt);

#endif
