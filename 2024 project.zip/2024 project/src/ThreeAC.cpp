#include "ThreeAC.h"
#include <stdio.h>
#include <string.h>

// Global list to store 3-address code instructions
// Initialize it with a size enough to hold a reasonable number of instructions
ThreeAddressCode tac_list[1000]; // Adjust the size as needed

// Function to generate 3-address code
void gen_code(char* op, char* arg1, char* arg2, char* result) {
    tac_list[tac_index].op = op;
    tac_list[tac_index].arg1 = arg1;
    tac_list[tac_index].arg2 = arg2;
    tac_list[tac_index].result = result;
    tac_index++;
}


// Read 3-address code instructions from file
void read_3ac(FILE* input_file, ThreeAddressCode* tac_list, int* tac_count) {
    // Read each line from the input file
    while (fscanf(input_file, "%s %s %s %s", tac_list[*tac_count].op, 
                                            tac_list[*tac_count].arg1, 
                                            tac_list[*tac_count].arg2, 
                                            tac_list[*tac_count].result) == 4) {
        (*tac_count)++;
    }
}

// Translate 3-address code to x86_64 assembly
void translate_to_assembly(ThreeAddressCode* tac_list, int tac_count) {
    // Iterate through each 3AC instruction and translate to assembly
    for (int i = 0; i < tac_count; i++) {
        // Translate each type of 3AC instruction to assembly
        // Example:
        if (strcmp(tac_list[i].op, "ADD") == 0) {
            printf("add %s, %s, %s\n", tac_list[i].result, tac_list[i].arg1, tac_list[i].arg2);
        }
        // Add more translation rules for other instructions
    }
}

