# README

```shell
flex lexer.l
bison -d parser.y
g++ -c symboltable.cpp ThreeAC.cpp
g++ -c lex.yy.c parser.tab.c runtime_environment.c
g++ symboltable.o ThreeAC.o lex.yy.o parser.tab.o runtime_environment.o -o output
```
