#ifndef ASTNODE_H
#define ASTNODE_H

#include <stddef.h>
#include <string.h>

typedef struct ASTNode {
    char *type;
    char *sym; 
    struct ASTNode* left;
    struct ASTNode* right;
    int globalindex;
    char* reg = strdup("default_reg");
} ASTNode;

// Use designated initializers to set pointers to NULL
static inline ASTNode createASTNode() {
    return (ASTNode){ .type = NULL, .sym = NULL, .left = NULL, .right = NULL };
}

#endif /* ASTNODE_H */
