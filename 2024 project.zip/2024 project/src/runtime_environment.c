// runtime_environment.c

#include <stdio.h>
#include <stdlib.h>

#include "runtime_environment.h" // Header file for the runtime environment

// Function to create a new activation record
ActivationRecord* create_activation_record() {
    ActivationRecord* ar = (ActivationRecord*)malloc(sizeof(ActivationRecord));
    if (ar == NULL) {
        fprintf(stderr, "Memory allocation failed for activation record\n");
        exit(EXIT_FAILURE);
    }
    // Initialize fields to appropriate values
    ar->parameters = NULL;
    ar->return_value = NULL;
    ar->old_stack_pointer = NULL;
    ar->saved_registers = NULL;
    ar->locals = NULL;
    return ar;
}

// Function to destroy an activation record and free memory
void destroy_activation_record(ActivationRecord* ar) {
    if (ar != NULL) {
        free(ar);
    }
}

// Function to set the space for actual parameters
void set_parameters_space(ActivationRecord* ar, void* parameters) {
    ar->parameters = parameters;
}

// Function to set the space for return value
void set_return_value_space(ActivationRecord* ar, void* return_value) {
    ar->return_value = return_value;
}

// Function to set the space for old stack pointer
void set_old_stack_pointer_space(ActivationRecord* ar, void* old_stack_pointer) {
    ar->old_stack_pointer = old_stack_pointer;
}

// Function to set the space for saved registers
void set_saved_registers_space(ActivationRecord* ar, void* saved_registers) {
    ar->saved_registers = saved_registers;
}

// Function to set the space for locals
void set_locals_space(ActivationRecord* ar, void* locals) {
    ar->locals = locals;
}


