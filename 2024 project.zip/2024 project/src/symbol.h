#ifndef SYMBOL_H
#define SYMBOL_H

typedef struct symbol {
    char *name;
    char* type;
    int size;
    int offset;
    int line;
    char *file;
    struct symbol *next;
    struct symbol *scope;
    char* reg;
} symbol;

#endif /* SYMBOL_H */