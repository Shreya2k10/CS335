def main():
  a: int = 1
  b: int = 2
  if a==0:
    j:int = 4
  else:
    j = 8

if __name__ == "__main__":
  main()
