def main():
  print("Hello World")
  o:int = 66
  k:int = 55
  o = k + o
  l:str = "hello world"


if __name__ == "__main__":
  main()

