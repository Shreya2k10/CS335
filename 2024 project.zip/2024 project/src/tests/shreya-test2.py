def main():
  a: int = 1
  b: int = 2
  if a < b:
    a = a + b
  else:
    a = a - b
  print(a)


if __name__ == "__main__":
  main()
