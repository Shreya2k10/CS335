def main():
 a: int = 1
 print(a)


if __name__ == "__main__":
  main()
  a=0
