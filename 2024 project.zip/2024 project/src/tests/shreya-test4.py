def main():
  a: int = 1
  b: int = 5
  while a < b:
    a = a + 1
  print(a)
  print(b)


if __name__ == "__main__":
  main()
