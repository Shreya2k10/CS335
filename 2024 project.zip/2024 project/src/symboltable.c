
#include "symbol.h"
#include "astnode.h"

#include "symboltable.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>



symbol* search_symbol(char* name, local_table* lt) {
    symbol* sym = lt->params;
    while (sym != NULL) {
        if (strcmp(sym->name, name) == 0) {
            return sym;
        }
        sym = sym->next;
    }
    sym = lt->vars;
    while (sym != NULL) {
        if (strcmp(sym->name, name) == 0) {
            return sym;
        }
        sym = sym->next;
    }
    return NULL;
}


symbol* lookup(char* name) {
    local_table* lt = find_local_table(current_func);
    if (lt == NULL) {
        return NULL;
    }

    // Search for the symbol in the local table
    symbol* sym = search_symbol(name, lt);
    if (sym != NULL) {
        return sym;
    }

    // If not found in local table, search in global table
    return search_symbol(name, global_table);
}


// A function to create a new symbol with the given information
symbol *create_symbol(char *name, char* type, int size, int offset, int line, char *file) {
  symbol *s = (symbol *)malloc(sizeof(symbol));
  s->name = strdup(name);
  s->type = type;
  s->size = size;
  s->offset = offset;
  s->line = line;
  s->file = file ? strdup(file): NULL;
  s->next = NULL;
  return s;
}

// A function to create a new local table with the given function name
local_table *create_local_table(char *func_name) {
  local_table *lt = (local_table *)malloc(sizeof(local_table));
  lt->func_name = strdup(func_name);
  lt->params = NULL;
  lt->vars = NULL;
  lt->next = NULL;
  insert_local_table (lt);
  return lt;
}



// A function to insert a symbol into a linked list of symbols
void insert_symbol(symbol **head, symbol *s) {
  if (*head == NULL) {
    *head = s;
  } else {
    symbol *curr = *head;
    while (curr->next != NULL) {
      curr = curr->next;
    }
    curr->next = s;
  }
}

// A function to insert a local table into the global table
void insert_local_table(local_table *lt) {
  if (global_table == NULL) {
    global_table = lt;
  } else {
    local_table *curr = global_table;
    while (curr->next != NULL) {
      curr = curr->next;
    }
    curr->next = lt;
  }
}

// A function to find a local table by the function name
local_table *find_local_table(char *func_name) {
  local_table *curr = global_table;
  while (curr != NULL) {
    if (strcmp(curr->func_name, func_name) == 0) {
      return curr;
    }
    curr = curr->next;
  }
  return NULL;
}

// A function to print a symbol
void print_symbol(symbol *s) {
  printf("%s\t%s\t%d\t%d\t%d\t%s\n", s->name, s->type, s->size, s->offset, s->line, s->file);
}

// A function to print a local table
void print_local_table(local_table *lt) {
  printf("Function: %s\n", lt->func_name);
  printf("Parameters:\n");
  symbol *p = lt->params;
  while (p != NULL) {
    print_symbol(p);
    p = p->next;
  }
  printf("Local variables:\n");
  symbol *v = lt->vars;
  while (v != NULL) {
    print_symbol(v);
    v = v->next;
  }
}

// A function to print the global table
void print_global_table() {
  local_table *curr = global_table;
  while (curr != NULL) {
    print_local_table(curr);
    curr = curr->next;
  }
}

void dump_symbol_table_to_csv(local_table *lt) {
    // Open a CSV file for the function
    char filename[100];
    sprintf(filename, "%s.csv", lt->func_name);
    FILE *csv_file = fopen(filename, "w");
    if (csv_file == NULL) {
        fprintf(stderr, "Error opening file %s for writing.\n", filename);
        return;
    }

    // Write header row
    fprintf(csv_file, "Syntactic Category, Lexeme, Type, Line Number\n");

    // Traverse the symbol table and write data rows
    symbol *sym = lt->params;
    while (sym != NULL) {
        fprintf(csv_file, "Parameter, %s, %s, %d\n", sym->name, sym->type, sym->line);
        sym = sym->next;
    }
    sym = lt->vars;
    while (sym != NULL) {
        fprintf(csv_file, "Variable, %s, %s, %d\n", sym->name, sym->type, sym->line);
        sym = sym->next;
    }

    // Close the CSV file
    fclose(csv_file);
}

void dump_all_symbol_tables_to_csv() {
    local_table *curr = global_table;
    while (curr != NULL) {
        dump_symbol_table_to_csv(curr);
        curr = curr->next;
    }
}

void generate_3ac(ASTNode *node, FILE *output_file) {
    // Base case: If node is NULL, return
    if (node == NULL) {
//        printf("Hi");

        return;
    }

    // Process node based on its type
    // Example: If the node type is assignment, generate corresponding 3AC
    if (strcmp(node->type, "Assignment") == 0) {
        // Example: Generate 3AC for assignment operation
        fprintf(output_file, "%s = %s %s %s\n", node->left->sym, node->right->sym, node->sym, node->right->sym);
    }

    // Recursively process children of the current node
    generate_3ac(node->left, output_file);
    generate_3ac(node->right, output_file);
}

void dump_3ac_to_text(ASTNode *function_node) {
    // Open a text file for dumping 3AC
    char filename[100];
    sprintf(filename, "%s_3ac.txt", function_node->sym);
    FILE *output_file = fopen(filename, "w");
    /*printf(filename, "%s");*/
    if (output_file == NULL) {
        fprintf(stderr, "Error opening file %s for writing.\n", filename);
        return;
    }

    // Generate 3AC for the function and output to the text file
    generate_3ac(function_node, output_file);

    // Close the text file
    fclose(output_file);
}