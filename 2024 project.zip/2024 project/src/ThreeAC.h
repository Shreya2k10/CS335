#include <stdio.h>
#ifndef THREEAC_H
#define THREEAC_H

// Define 3-address code instructions
typedef struct {
    char* op;
    char* arg1;
    char* arg2;
    char* result;
} ThreeAddressCode;

static long tac_index ; // Index to keep track of the next available slot in the list

// Function prototype for generating 3-address code
void gen_code(char* op, char* arg1, char* arg2, char* result);

void read_3ac(FILE* input_file, ThreeAddressCode* tac_list, int* tac_count);

void translate_to_assembly(ThreeAddressCode* tac_list, int tac_count);



#endif /* THREEAC_H */