/* A Bison parser, made by GNU Bison 3.5.1.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2020 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

#ifndef YY_YY_PARSER_TAB_H_INCLUDED
# define YY_YY_PARSER_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    Identifier = 258,
    Integer = 259,
    Float = 260,
    String = 261,
    TypeHint = 262,
    List = 263,
    ARITHMETIC_OPERATOR = 264,
    RELATIONAL_OPERATOR = 265,
    LOGICAL_OPERATOR = 266,
    BITWISE_OPERATOR = 267,
    ASSIGNMENT_OPERATOR = 268,
    CONTROL_FLOW = 269,
    Print = 270,
    Class = 271,
    Object_or_methodcall = 272,
    MethodDef = 273,
    Inheritance = 274,
    Main = 275,
    Loop = 276,
    INDENT = 277,
    DEDENT = 278,
    Right_parem = 279,
    Left_paren = 280,
    Opening_square_brace = 281,
    Closing_square_brace = 282,
    Opening_curly_brace = 283,
    Closing_curly_brace = 284,
    Boolean = 285,
    NAME_KEYWORD = 286,
    INIT_KEYWORD = 287,
    MAIN_KEYWORD = 288,
    Datatype_name = 289,
    Comma = 290,
    Return = 291,
    Listof = 292,
    WHILE = 293,
    IF = 294,
    SLSE = 295,
    PrimitiveType = 296,
    NEWLINE = 297,
    ELSE = 298
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 80 "parser.y"

    struct ASTNode * ASTNode ;

#line 105 "parser.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_PARSER_TAB_H_INCLUDED  */
