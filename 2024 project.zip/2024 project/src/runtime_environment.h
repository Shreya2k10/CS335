// runtime_environment.h
#ifndef RUNTIME_ENVIRONMENT_H
#define RUNTIME_ENVIRONMENT_H

// Structure representing an activation record
typedef struct ActivationRecord {
    void* parameters;        // Space for actual parameters
    void* return_value;      // Space for return value
    void* old_stack_pointer; // Space for old stack pointer
    void* saved_registers;   // Space for saved registers
    void* locals;            // Space for locals
} ActivationRecord;

// Function prototypes
ActivationRecord* create_activation_record();
void destroy_activation_record(ActivationRecord* ar);
void set_parameters_space(ActivationRecord* ar, void* parameters);
void set_return_value_space(ActivationRecord* ar, void* return_value);
void set_old_stack_pointer_space(ActivationRecord* ar, void* old_stack_pointer);
void set_saved_registers_space(ActivationRecord* ar, void* saved_registers);
void set_locals_space(ActivationRecord* ar, void* locals);


#endif /* RUNTIME_ENVIRONMENT_H */