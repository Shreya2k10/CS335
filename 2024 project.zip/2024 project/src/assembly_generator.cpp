#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ThreeAC.h"
extern long tac_index;
extern ThreeAddressCode tac_list[1000];

void generate_assembly() {
    FILE *output_file = fopen("output.s", "w");
    if (output_file == NULL) {
        perror("Error opening output file");
        exit(EXIT_FAILURE);
    }

    // Header section
    fprintf(output_file, ".global _start\n");
    fprintf(output_file, ".section .text\n");

    // Function Prologue
    fprintf(output_file, "_start:\n");
    fprintf(output_file, "pushq %%rbp\n");
    fprintf(output_file, "movq %%rsp, %%rbp\n");

    // Variables to track labels for control flow
    int label_counter = 0;
    char label_buffer[16];

    // Iterate over the three-address code instructions
    for (long i = 0; i < tac_index; i++) {
        // Generate assembly code based on the operation
        if (strcmp(tac_list[i].op, "ADD") == 0) {
            fprintf(output_file, "addq %s, %s\n", tac_list[i].arg1, tac_list[i].result);
        } else if (strcmp(tac_list[i].op, "SUB") == 0) {
            fprintf(output_file, "subq %s, %s\n", tac_list[i].arg1, tac_list[i].result);
        } else if (strcmp(tac_list[i].op, "MUL") == 0) {
            fprintf(output_file, "imulq %s, %s\n", tac_list[i].arg1, tac_list[i].result);
        } else if (strcmp(tac_list[i].op, "DIV") == 0) {
            fprintf(output_file, "cqo\n"); // Sign extend %rax into %rdx (for division)
            fprintf(output_file, "idivq %s\n", tac_list[i].arg1);
            fprintf(output_file, "movq %%rax, %s\n", tac_list[i].result);
        } else if (strcmp(tac_list[i].op, "FUNC_CALL") == 0) {
            // Function call handling
            // Push arguments onto the stack
            // Assuming arguments are passed in registers or on the stack
            // Call the function
            fprintf(output_file, "call %s\n", tac_list[i].arg1);
            // Handle return value if needed
            // Assuming return value is stored in %rax
            fprintf(output_file, "movq %%rax, %s\n", tac_list[i].result);
            // Clean up the stack
            fprintf(output_file, "addq $%d, %%rsp\n", 8); // Assuming 8 bytes for argument space
        } else if (strcmp(tac_list[i].op, "JMP") == 0) {
            // Unconditional jump
            fprintf(output_file, "jmp %s\n", tac_list[i].arg1);
        } else if (strcmp(tac_list[i].op, "JE") == 0) {
            // Jump if equal
            fprintf(output_file, "je %s\n", tac_list[i].arg1);
        } else if (strcmp(tac_list[i].op, "JNE") == 0) {
            // Jump if not equal
            fprintf(output_file, "jne %s\n", tac_list[i].arg1);
        } else {
            // Handle other operations or errors
            fprintf(stderr, "Unsupported operation: %s\n", tac_list[i].op);
            exit(EXIT_FAILURE);
        }

        // Variable access (assuming variables are accessed through memory)
        // Load and store operations between memory and registers
        fprintf(output_file, "movq %s, %%rax\n", tac_list[i].arg1);
        fprintf(output_file, "movq %%rax, %s\n", tac_list[i].result);
    }

    // Function Epilogue
    fprintf(output_file, "popq %%rbp\n");
    fprintf(output_file, "ret\n");

    fclose(output_file);
}
